# MIAI_PCA_Demo
A demo of using PCA

Article link: https://www.miai.vn/2021/04/22/principal-component-analysis-pca-tuyet-chieu-giam-chieu-du-lieu/

#MìAI <br>
Fanpage: http://facebook.com/miaiblog<br>
Group trao đổi, chia sẻ: https://www.facebook.com/groups/miaigroup<br>
Website: http://miai.vn<br>
Youtube: http://bit.ly/miaiyoutube<br>

