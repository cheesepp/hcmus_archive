#include "File.h"
int main() {

	ghi3SoNguyen("outputghi3so.txt");
	giaiPTBac2("ptbac2.txt", "outputptb2.txt");
	int a[100];
	sapXep("chuasap.txt", "outputsapxep.txt", a);
	nhapVanBan("outputvb.txt");
	inTapTin("ptbac2.txt");
	demSoChuCai("outputvb.txt", "demchucai.txt");
	demSoTu("outputvb.txt", "demsotu.txt");
	doiThuongThanhHoa("outputvb.txt", "outputhoa.txt");
	ghep2File("ghep2file.txt", "ghep2file1.txt", "outputghep.txt");
	ghiStruct("outputstruct.txt", "outputstruct.txt");
}