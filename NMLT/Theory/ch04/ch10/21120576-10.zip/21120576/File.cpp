﻿#include "File.h"

void ghi3SoNguyen(string filename) {
    int a, b, c;

    cout << "Nhap a: ";
    cin >> a;

    cout << "Nhap b: ";
    cin >> b;

    cout << "Nhap c: ";
    cin >> c;

    ofstream file(filename);

    if (file.is_open()) {
        file << a << " " << b << " " << c << endl;

        file.close();

        cout << "Ghi file thanh cong!" << endl;
    }
    else {
        cout << "Không thể mở tập tin để ghi!" << endl;
    }
}

void doc3SoNguyen(string filename) {
    ifstream fin(filename);

    if (fin.is_open()) {
        int a, b, c;

        fin >> a >> b >> c;

        fin.close();
    }
}

void giaiPTBac2(string input, string output) {
    
    int a, b, c;
    ifstream fin(input);

    if (fin.is_open()) {

        fin >> a >> b >> c;

        fin.close();
    }

    ofstream fout(output);

    if (fout.is_open()) {
        int delta = b * b - 4 * a * c;

        if (delta > 0) {
            double x1 = (-b + sqrt(delta)) / (2 * a);
            double x2 = (-b - sqrt(delta)) / (2 * a);

            fout << "Hai nghiem phan biet:" << endl;
            fout << "x1 = " << x1 << endl;
            fout << "x2 = " << x2 << endl;
        }
        else if (delta == 0) {
            double x = -b / (2 * a);

            fout << "Mot nghiem kep:" << endl;
            fout << "x = " << x << endl;
        }
        else {
            fout << "Khong co nghiem thuc" << endl;
        }
        cout << "Ghi ket qua vao file '" << output << "' thanh cong!" << endl;
    }
    fout.close();
}

void sapXep(string input, string output, int a[]) {
    int n;
    ifstream fin(input);
    if (fin.is_open()) {
        fin >> n;
        for (int i = 0; i < n; i++) {
            fin >> a[i];
        }
    }
    fin.close();
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                swap(a[i], a[j]);
            }
        }
    }
    ofstream fout(output);
    if (fout.is_open()) {
        for (int i = 0; i < n; i++) {
            fout << a[i] << " ";
        }
        cout << "Ghi vao file '" << output << "' thanh cong!" << endl;
    }
    fout.close();
}

void nhapVanBan(string output) {

    ofstream file(output);

    if (file.is_open()) {
        string line;

        cout << "Nhap cac dong van ban (nhap 0 de ket thuc)\n";

        while (getline(cin, line) && line != "0") {
            file << line << endl;
        }

        file.close();

        cout << "Ghi vao file '" << output << "' thanh cong!" << endl;
    }
    else {
        cout << "Khong the mo file!" << endl;
    }
}

void inTapTin(string input) {
    ifstream file(input);
    if (file.is_open()) {
        string line;

        cout << "Noi dung cua tap tin '" << input << "':" << endl;


        while (getline(file, line)) {
            cout << line << endl;
        }

        file.close();
    }
    else {
        cout << "Khong the mo file " << input << "!" << endl;
    }
}

int countLetters(const string& text) {
    int count = 0;

    for (char c : text) {
        if (isalpha(c)) {
            count++;
        }
    }

    return count;
}

void demSoChuCai(string input, string output) {

    ifstream inputFile(input);

    if (inputFile.is_open()) {
        string fileContent((istreambuf_iterator<char>(inputFile)), istreambuf_iterator<char>());

        inputFile.close();

        int letterCount = countLetters(fileContent);

        ofstream outputFile(output);

        if (outputFile.is_open()) {

            outputFile << "So ki tu chu cai: " << letterCount << endl;

            outputFile.close();

            cout << "Ghi vao file '" << output << "' thanh cong!" << endl;
        }
        else {
            cout << "Khong the mo file " << output << "!" << endl;
        }
    }
    else {
        cout << "Khong the mo file " << input << "!" << endl;
    }

}

int countWords(const string& text) {
    int count = 0;
    istringstream iss(text);

    string word;
    while (iss >> word) {
        count++;
    }

    return count;
}

void demSoTu(string input, string output) {

    ifstream inputFile(input);

    if (inputFile.is_open()) {

        string fileContent((istreambuf_iterator<char>(inputFile)), istreambuf_iterator<char>());

        inputFile.close();

        int wordCount = countWords(fileContent);

        ofstream outputFile(output);

        if (outputFile.is_open()) {
            outputFile << "So tu: " << wordCount << endl;

            outputFile.close();

            cout << "Ghi vao file '" << output << "' thanh cong!" << endl;
        }
        else {
            cout << "Khong the mo file " << output << "!" << endl;
        }
    }
    else {
        cout << "Khong the mo file " << input << "!" << endl;
    }
}

void doiThuongThanhHoa(string input, string output) {

    ifstream inputFile(input);

    if (inputFile.is_open()) {

        ofstream outputFile(output);

        if (outputFile.is_open()) {
            char c;

            while (inputFile.get(c)) {
                if (islower(c)) {
                    c = toupper(c);
                }

                outputFile << c;
            }

            outputFile.close();

            cout << "Sao chep tap tin va ghi vao file: " << output << " thanh cong!" << endl;
        }
        else {
            cout << "Khong the mo file " << output << "! " << endl;
        }

        inputFile.close();
    }
    else {
        cout << "Khong the mo file " << input << "! " << endl;
    }
}

void ghep2File(string input1, string input2, string output) {

    ifstream inputFile1(input1);

    if (inputFile1.is_open()) {
        ifstream inputFile2(input2);

        if (inputFile2.is_open()) {

            ofstream outputFile(output);

            if (outputFile.is_open()) {
                string line;

                while (getline(inputFile1, line)) {
                    outputFile << line << endl;
                }

                while (getline(inputFile2, line)) {
                    outputFile << line << endl;
                }

                outputFile.close();

                cout << "Ghi vao file '" << output << "' thanh cong!" << endl;
            }
            else {
                cout << "Khong the mo file " << output << "! " << endl;
            }

            inputFile2.close();
        }
        else {
            cout << "Khong the mo file " << input2 << "! " << endl;
        }

        inputFile1.close();
    }
    else {
        cout << "Khong the mo file " << input1 << "! " << endl;
    }

}

struct Date {
    int ngay;
    int thang;
    int nam;
};

void ghiStruct(string output, string input) {

    ofstream outputFile(output);

    if (outputFile.is_open()) {

        Date danhSach[] = {
            {1, 1, 1999},
            {2, 2, 2000},
            {3, 3, 2003}
        };

        for (int i = 0; i < 3; i++) {
            outputFile << danhSach[i].ngay << "/" << danhSach[i].thang << "/" << danhSach[i].nam << endl;
        }

        outputFile.close();

        cout << "Ghi vao file '" << output << "' thanh cong!" << endl;
    }
    else {
        cout << "Khong the mo file " << output << "! " << endl;
        return;
    }

    ifstream inputFile(input);

    if (inputFile.is_open()) {

        string line;
        while (getline(inputFile, line)) {
            int ngay;
            int thang;
            int nam;
            ngay = stoi(line.substr(0, line.find_first_of('/')));
            thang = stoi(line.substr(line.find_first_of('/') + 1, line.find_last_of('/')));
            nam = stoi(line.substr(line.find_last_of('/') + 1));

            cout << ngay << "/" << thang << "/" << nam << endl;
        }

        inputFile.close();

        cout << "Doc file " << input << " thanh cong!\n";
    }
    else {
        cout << "Khong the mo file " << input << "! " << endl;
    }
}