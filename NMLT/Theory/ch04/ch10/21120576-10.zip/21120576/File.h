#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

void ghi3SoNguyen(string filename);
void giaiPTBac2(string input, string output);
void sapXep(string input, string output, int a[]);
void nhapVanBan(string output);
void inTapTin(string input);
void demSoChuCai(string input, string output);
void demSoTu(string input, string output);
void doiThuongThanhHoa(string input, string output);
void ghep2File(string input1, string input2, string output);
void ghiStruct(string output, string input);
