#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Date {
	int day;
	int month;
	int year;
};

void input(Date& d);
void output(Date d);
const char* numToText(int month);
void outputDateWithFormat(Date d, const char* format);
void readDate(Date& d, const char* filename);
void writeFile(Date d, const char* filename);
void increaseDateBy1(Date& d);
void increaseDateByK(Date& d, int k);
void decreaseDateBy1(Date& d);
void decreaseDateByK(Date& d, int k);
bool isLeapYear(int year);
int getDaysInMonth(int month, int year);
int calculateDays(Date d);
int compare2Dates(Date d, Date d2);
int DistanceWithSameYear(Date d);
int DistanceWith1970(Date d);
int Distance(Date d1, Date d2);
string getDayOfWeek(Date d);