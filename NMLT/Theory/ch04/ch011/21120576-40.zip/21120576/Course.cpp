#include "Course.h"

Course loadCourseFromFile(string filename) {
    Course course;
    ifstream fin(filename);

    if (fin.is_open()) {
        getline(fin, course.courseId);
        getline(fin, course.courseName);

        Student s;
        course.numStudents = 0;
        string num;
        getline(fin, num);

        course.numStudents = stoi(num);
        int i = 0;
        while (i < course.numStudents) {
            string id;
            getline(fin, id);
            s.id = stol(id);
            getline(fin, s.fullname);
            string gpa;
            getline(fin, gpa);
            s.gpa = stof(gpa);
            getline(fin, s.address);
            string line;
            getline(fin, line);
            int first = -1;
            int sec = -1;
            for (int i = 0; i < line.length(); i++) {
                if (line[i] == ' ' || line[i] == '/' || line[i] == '-') {
                    if (first > -1) {
                        sec = i;
                        break;
                    }
                    first = i;
                }
            }

            s.dayOfBirth.day = stoi(line.substr(0, first));
            s.dayOfBirth.month = stoi(line.substr(first + 1, sec));
            s.dayOfBirth.year = stoi(line.substr(sec + 1));

            course.students[i++] = s;
        }
        fin >> course.status >> course.maxStudents >> course.minStudents;
        fin.close();
    }

    return course;
}

void saveCourseToFile(Course course, string filename) {
    ofstream file(filename);

    if (file.is_open()) {
        file << course.courseId << '\n';
        file << course.courseName << '\n';
        file << course.numStudents << endl;
        for (int i = 0; i < course.numStudents; i++) {
            writeStudent(course.students[i], filename);
        }
        file << course.status << '\n';
        file << course.maxStudents << '\n';
        file << course.minStudents << '\n';
        file.close();
    }
}

void addStudentToCourse(Course& course, Student student) {
    if (course.numStudents < course.maxStudents) {
        course.students[course.numStudents] = student;
        course.numStudents++;
    }
    else {
        cout << "Course dat so luong sinh vien toi da!" << endl;
    }
}

void removeStudentFromCourse(Course& course, Student student) {
    int index = -1;
    for (int i = 0; i < course.numStudents; i++) {
        if (course.students[i].id == student.id) {
            index = i;
            break;
        }
    }

    if (index != -1) {
        for (int i = index; i < course.numStudents - 1; i++) {
            course.students[i] = course.students[i + 1];
        }
        course.numStudents--;

        if (course.numStudents < course.minStudents) {
            course.status = "close";
        }
    }
    else {
        cout << "Khong tim thay sinh vien trong course" << endl;
    }
}

string getCurrentDate() {
    time_t now = time(nullptr);
    char dateBuffer[80];
    strftime(dateBuffer, sizeof(dateBuffer), "%Y-%m-%d", localtime(&now));
    return string(dateBuffer);
}

void saveStudentsBornInCurrentMonth(Course course, string filename) {
    string currentDate = getCurrentDate();
    int currentMonth = stoi(currentDate.substr(5, 2));

    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            int studentMonth = course.students[i].dayOfBirth.month;
            if (studentMonth == currentMonth) {
                writeStudent(course.students[i], filename);
            }
        }
        file.close();
    }
}

void saveStudentsBornOnCurrentDate(Course course, string filename) {
    string currentDate = getCurrentDate();
    cout << currentDate << endl;

    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            int dob = course.students[i].dayOfBirth.day;
            if (dob == stoi(currentDate)) {
                writeStudent(course.students[i], filename);
            }
        }
        file.close();
    }
}

void saveLegalDrivingStudents(Course course, string filename) {
    string currentDate = getCurrentDate();
    int currentYear = stoi(currentDate.substr(0, 4));

    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            int dob = course.students[i].dayOfBirth.year;
            if (currentYear - dob >= 18) {
                writeStudent(course.students[i], filename);
            }
        }
        file.close();
    }
}

void saveStudentsInK19Class(Course course, string filename) {
    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            if (course.students[i].id / 1000000 != 19) {
                writeStudent(course.students[i], filename);
            }
        }
        file.close();
    }
}

void findStudentById(Course course, long id, string filename) {
    ofstream file(filename);

    if (file.is_open()) {
        bool found = false;
        for (int i = 0; i < course.numStudents; i++) {
            if (course.students[i].id == id) {
                file << "Tim thay sinh vien: ";
                writeStudent(course.students[i], filename);
                found = true;
                break;
            }
        }
        if (!found) {
            file << "Khong tim thay sinh vien!" << '\n';
        }
        file.close();
    }
}

void findStudentsByName(Course course, string name, string filename) {
    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            if (course.students[i].fullname == name) {
                file << "Student found: ";
                writeStudent(course.students[i], filename);
            }
        }
        file.close();
    }
}

void sortStudentsById(Course course, string filename) {
    for (int i = 0; i < course.numStudents; i++) {
        for (int j = i + 1; j < course.numStudents; j++) {
            if (course.students[i].id / 1000000 < course.students[j].id / 1000000) {
                Student temp = course.students[i];
                course.students[i] = course.students[j];
                course.students[j] = temp;
            }
        }
    }

    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            writeStudent(course.students[i],filename);
        }
        file.close();
    }
}

void sortStudentsByFirstName(Course course, string filename) {

    for (int i = 0; i < course.numStudents; i++) {
            string firstName1 = course.students[i].fullname.substr(0, course.students[i].fullname.find_first_of(' '));
        for (int j = i + 1; j < course.numStudents; j++) {
            string firstName2 = course.students[j].fullname.substr(0, course.students[j].fullname.find_first_of(' '));
            if (firstName1 > firstName2) {
                Student temp = course.students[i];
                course.students[i] = course.students[j];
                course.students[j] = temp;
            }
        }
    }


    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            writeStudent(course.students[i], filename);
        }
        file.close();
    }
}

void sortStudentsByGPA(Course course, string filename) {
   
    for (int i = 0; i < course.numStudents; i++) {
        for (int j = i + 1; j < course.numStudents; j++) {
            if (course.students[i].gpa > course.students[j].gpa) {
                Student temp = course.students[i];
                course.students[i] = course.students[j];
                course.students[j] = temp;
            }
        }
    }

    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            writeStudent(course.students[i], filename);
        }
        file.close();
    }
}

void sortStudentsByDOB(Course course, string filename) {
    
    for (int i = 0; i < course.numStudents; i++) {
        for (int j = i + 1; j < course.numStudents; j++) {
            if (compare2Dates(course.students[i].dayOfBirth, course.students[j].dayOfBirth)) {
                Student temp = course.students[i];
                course.students[i] = course.students[j];
                course.students[j] = temp;
            }
        }
    }

    ofstream file(filename);

    if (file.is_open()) {
        for (int i = 0; i < course.numStudents; i++) {
            writeStudent(course.students[i], filename);
        }
        file.close();
    }
}