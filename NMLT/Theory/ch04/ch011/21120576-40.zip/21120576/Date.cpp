#include "Date.h"

void input(Date& d) {
	cout << "Nhap ngay: ";
	cin >> d.day;
	cout << "Nhap thang: ";
	cin >> d.month;
	cout << "Nhap nam: ";
	cin >> d.year;
}

void output(Date d) {
	cout << d.year << "-" << d.month << "-" << d.day << endl;
}

const char* numToText(int month) {
	if (month == 1) return "Jan";
	if (month == 2) return "Feb";
	if (month == 3) return "Mar";
	if (month == 4) return "Apr";
	if (month == 5) return "May";
	if (month == 6) return "Jun";
	if (month == 7) return "Jul";
	if (month == 8) return "Aug";
	if (month == 9) return "Sep";
	if (month == 10) return "Oct";
	if (month == 11) return "Nov";
	if (month == 12) return "Dec";
}

void outputDateWithFormat(Date d, const char* format) {
	char format2[20];
	strcpy(format2, format);
	strcat(format2, ".");
	int countY = 0;
	int countM = 0;
	int countD = 0;
	bool hasPrintY = 0;
	bool hasPrintM = 0;
	bool hasPrintD = 0;
	for (int i = 0; i < strlen(format2); i++) {
		if (format2[i] == 'y') {
			countY++;
			continue;
		}
		if (!hasPrintY && countY > 0) {
			if (countY == 2) {
				cout << d.year % 100;
				hasPrintY = 1;
			}
			else if (countY == 4) {
				cout << d.year;
				hasPrintY = 1;
			}
		}
		if (format2[i] == 'M') {
			countM++;
			continue;
		}
		if (!hasPrintM && countM > 0) {
			if (countM == 1) {
				cout << d.month;
				hasPrintM = 1;
			}
			else if (countM == 2) {
				if (d.month < 10)
					cout << 0 << d.month;
				else cout << d.month;
				hasPrintM = 1;
			}
			else if (countM == 3) {
				cout << numToText(d.month);
				hasPrintM = 1;
			}
		}
		if (format2[i] == 'd') {
			countD++;
			continue;
		}
		if (!hasPrintD && countD > 0) {
			if (countD == 1) {
				cout << d.day;
				hasPrintD = 1;
			}
			else if (countD == 2) {
				if (d.day < 10)
					cout << 0 << d.day;
				else cout << d.day;
				hasPrintD = 1;
			}
		}
		if (format[i] == '/' || format[i] == '-' || format[i] == ' ') {
			cout << format[i];
		}
	}
	cout << endl;
}

void readDate(Date& d, const char* filename) {
	ifstream fin(filename);
	if (!fin) {
		cout << "Khong mo duoc file!\n";
		return;
	}
	cout << "Mo file thanh cong!\n";
	string line;
	getline(fin, line);
	int first = -1;
	int sec = -1;
	for (int i = 0; i < line.length(); i++) {
		if (line[i] == ' ' || line[i] == '/' || line[i] == '-') {
			if (first > -1) {
				sec = i;
				break;
			}
			first = i;
		}
	}

	d.day = stoi(line.substr(0, first));
	d.month = stoi(line.substr(first + 1, sec));
	d.year = stoi(line.substr(sec + 1));
	fin.close();

}

void writeFile(Date d, const char* filename) {
	ofstream fout(filename);
	if (!fout) {
		cout << "Khong mo duoc file!\n";
		return;
	}
	cout << "Mo file thanh cong!\n";
	fout << d.day << " " << d.month << " " << d.year;
}

void increaseDateBy1(Date& d) {
	int tg;
	switch (d.month) {
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		tg = 31;
		break;
	case 2:
		if (d.year % 4 == 0)
			tg = 29;
		else tg = 28;
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		tg = 30;
		break;
	default:
		cout << "Khong tim thay!";
	}

	if (d.day == tg) {
		if (d.month == 12) {
			d.day++;
			d.month = 1;
			d.year++;
		}
		else {
			d.day = 1;
			d.month++;
		}
	}
	else {
		d.day++;
	}
}

void increaseDateByK(Date& d, int k) {
	while (k >= 0) {
		increaseDateBy1(d);
		k--;
	}
	output(d);
}

void decreaseDateBy1(Date& d) {
	int tg;
	switch (d.month) {
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		tg = 31;
		break;
	case 2:
		if (d.year % 4 == 0)
			tg = 29;
		else tg = 28;
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		tg = 30;
		break;
	default:
		cout << "Khong tim thay!";
	}

	if (d.day == 1) {
		if (d.month == 1) {
			d.day = 31;
			d.month = 12;
			d.year--;
		}
		else {
			d.month--;
			switch (d.month) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				d.day = 31;
				break;
			case 2:
				if (d.year % 4 == 0)
					d.day = 29;
				else d.day = 28;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				d.day = 30;
				break;
			}
		}
	}
	else {
		d.day--;
	}

	cout << "Ngay truoc do: " << endl;
	output(d);
}

void decreaseDateByK(Date& d, int k) {
	while (k >= 0) {
		decreaseDateBy1(d);
		k--;
	}
	output(d);
}

bool isLeapYear(int year) {
	return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int getDaysInMonth(int month, int year) {
	if (month == 2) {
		return isLeapYear(year) ? 29 : 28;
	}
	else if (month == 4 || month == 6 || month == 9 || month == 11) {
		return 30;
	}
	else {
		return 31;
	}
}

int calculateDays(Date d) {
	int totalDays = 0;

	int refYear = 1900;
	int refMonth = 1;
	int refDay = 1;

	for (int y = refYear; y < d.year; ++y) {
		totalDays += isLeapYear(y) ? 366 : 365;
	}

	for (int m = refMonth; m < d.month; ++m) {
		totalDays += getDaysInMonth(m, d.year);
	}

	totalDays += d.day - refDay;

	return totalDays;
}

int compare2Dates(Date d, Date d2) {
	int days1 = calculateDays(d);
	int days2 = calculateDays(d2);
	if (days1 < days2) {
		cout << "Ngay 1 truoc ngay 2\n";
		return 1;
	}
	else if (days1 > days2) {
		cout << "Ngay 1 sau ngay 2\n";
		return 0;
	}
	return -1;
}

int DistanceWithSameYear(Date d) {
	Date d2;
	d2.day = 1;
	d2.month = 1;
	d2.year = d.year;
	return calculateDays(d) - calculateDays(d2);
}

int DistanceWith1970(Date d) {
	Date d2;
	d2.day = 1;
	d2.month = 1;
	d2.year = 1970;
	return calculateDays(d) - calculateDays(d2);
}

int Distance(Date d1, Date d2) {
	return calculateDays(d1) - calculateDays(d2);
}

string getDayOfWeek(Date d) {
	string weekday[7] = { "Saturday","Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday" };
	int mon;
	if (d.month > 2)
		mon = d.month;
	else {
		mon = (12 + d.month);
		d.year--;
	}

	int y = d.year % 100;
	int c = d.year / 100;
	int w = (d.day + floor((13 * (mon + 1)) / 5) + y + floor(y / 4) + floor(c / 4) + (5 * c));
	w = w % 7;
	return weekday[w];
}