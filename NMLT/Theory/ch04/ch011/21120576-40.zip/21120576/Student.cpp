#include "Student.h"

void input(Student& s) {
	cout << "Nhap id: ";
	cin >> s.id;
	cout << "Nhap ho ten: ";
	cin.ignore();
	getline(cin, s.fullname, '\n');
	cout << "Nhap GPA: ";
	cin >> s.gpa;
	cout << "Nhap dia chi: ";
	cin.ignore();
	getline(cin, s.address, '\n');
	cout << "Nhap ngay sinh: \n";
	input(s.dayOfBirth);
}

void output(Student s) {
	cout << "ID: " << s.id << endl;
	cout << "Ho ten: " << s.fullname << endl;
	cout << "GPA: " << s.gpa << endl;
	cout << "Dia chi: " << s.address << endl;
	cout << "Ngay sinh: ";
	output(s.dayOfBirth);
}

void outputWAge(Student s) {
	output(s);
	cout << "Tuoi: " << 2023 - s.dayOfBirth.year << endl;
}

void readStudent(Student& s, string filename) {
	ifstream fin(filename);
	if (!fin) {
		cout << "Khong mo duoc file!\n";
		return;
	}
	cout << "Mo file thanh cong\n";
	string id;
	getline(fin, id);
	s.id = stol(id);
	getline(fin, s.fullname);
	string gpa;
	getline(fin, gpa);
	s.gpa = stof(gpa);
	getline(fin, s.address);
	string line;
	getline(fin, line);
	int first = -1;
	int sec = -1;
	for (int i = 0; i < line.length(); i++) {
		if (line[i] == ' ' || line[i] == '/' || line[i] == '-') {
			if (first > -1) {
				sec = i;
				break;
			}
			first = i;
		}
	}

	s.dayOfBirth.day = stoi(line.substr(0, first));
	s.dayOfBirth.month = stoi(line.substr(first + 1, sec));
	s.dayOfBirth.year = stoi(line.substr(sec + 1));
	fin.close();
}

void writeStudent(Student s, string filename) {
	ofstream fout(filename);
	if (!fout) {
		cout << "Khong mo duoc file!\n";
		return;
	}
	cout << "Mo file thanh cong!\n";
	fout << s.id << endl;
	fout << s.fullname << endl;
	fout << s.gpa << endl;
	fout << s.address << endl;
	fout << s.dayOfBirth.day << " " << s.dayOfBirth.month << " " << s.dayOfBirth.year;
}

void extractClass(Student s) {
	cout << "Khoa cua sinh vien la khoa K" << s.id / 1000000 << endl;
}

void compare2StdsById(Student s1, Student s2) {
	if (s1.id % 1000000 < s2.id % 1000000) {
		cout << "Sinh vien s1 lon hon sinh vien s2\n";
	}
	else cout << "Sinh vien s1 nho hon sinh vien s2\n";
}

void compare2StdsByGPAnId(Student s1,Student s2) {
	if (s1.gpa == s2.gpa) {
		compare2StdsById(s1, s2);
	}
	else if (s1.gpa < s2.gpa) {
		cout << "Sinh vien s1 co gpa thap hon sinh vien s2\n";
	}
	else cout << "Sinh vien s1 co gpa cao hon sinh vien s2\n";
}

void compare2StdsByNamenId(Student s1, Student s2) {
	if (s1.fullname == s2.fullname) {
		compare2StdsById(s1, s2);
	}
	else if (s1.fullname.length() < s2.fullname.length()) {
		cout << "Sinh vien s1 co ten ngan hon hon sinh vien s2\n";
	}
	else cout << "Sinh vien s1 co ten dai hon hon sinh vien s2\n";
}

void compare2StdsByFNamenId(Student s1, Student s2) {
	string firstName1 = s1.fullname.substr(0, s1.fullname.find_first_of(' '));
	string firstName2 = s2.fullname.substr(0, s2.fullname.find_first_of(' '));

	if (firstName1 == firstName2) {
		compare2StdsById(s1, s2);
	}
	else if (firstName1 < firstName2) {
		cout << "Sinh vien s1 co ten dau ngan hon hon sinh vien s2\n";
	}
	else cout << "Sinh vien s1 co ten dau dai hon hon sinh vien s2\n";
}

void compare2StdsByLNamenId(Student s1,Student s2) {
	string lastName1 = s1.fullname.substr(s1.fullname.find(' ') + 1);
	string lastName2 = s2.fullname.substr(s2.fullname.find(' ') + 1);

	if (lastName1 == lastName2) {
		compare2StdsById(s1, s2);
	}
	else if (lastName1 < lastName2) {
		cout << "Sinh vien s1 co ten cuoi ngan hon hon sinh vien s2\n";
	}
	else cout << "Sinh vien s1 co ten cuoi dai hon hon sinh vien s2\n";
}

void compare2StdsByDobnId(Student s1, Student s2) {
	 
	if (compare2Dates(s1.dayOfBirth, s2.dayOfBirth) == -1) {
		compare2StdsById(s1, s2);
	}
	else if (compare2Dates(s1.dayOfBirth, s2.dayOfBirth)) {
		cout << "Sinh vien s1 nho tuoi hon s2\n";
	}
	else cout << "Sinh vien s1 lon tuoi hon s2\n";
}



