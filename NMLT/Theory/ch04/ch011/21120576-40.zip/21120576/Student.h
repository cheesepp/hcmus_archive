#pragma once
#include "Date.h"

struct Student {
	long id;
	string fullname;
	float gpa;
	string address;
	Date dayOfBirth;
};

void input(Student& s);
void output(Student s);
void outputWAge(Student s);
void readStudent(Student &s, string filename);
void writeStudent(Student s, string filename);
void extractClass(Student s);
void compare2StdsById(Student s, Student s2);
void compare2StdsByGPAnId(Student s, Student s2);
void compare2StdsByNamenId(Student s, Student s2);
void compare2StdsByFNamenId(Student s, Student s2);
void compare2StdsByLNamenId(Student s, Student s2);
void compare2StdsByDobnId(Student s, Student s2);
