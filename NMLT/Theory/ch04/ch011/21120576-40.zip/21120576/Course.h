#pragma once
#define MAX 100
#include "Student.h"

struct Course {

    string courseId;
	string courseName;
	Student students[MAX];
	int numStudents;
	bool status;
	int maxStudents;
	int minStudents;

};

Course loadCourseFromFile(string filename);
void saveCourseToFile(Course course, string filename);
void addStudentToCourse(Course& course, Student student);
void removeStudentFromCourse(Course& course, Student student);
string getCurrentDate();
void saveStudentsBornInCurrentMonth(Course course, string filename);
void saveStudentsBornOnCurrentDate(Course course, string filename);
void saveLegalDrivingStudents(Course course, string filename);
void saveStudentsInK19Class(Course course, string filename);
void findStudentById(Course course, long id, string filename);
void findStudentsByName(Course course, string name, string filename);
void sortStudentsById(Course course, string filename);
void sortStudentsByFirstName(Course course, string filename);
void sortStudentsByGPA(Course course, string filename);
void sortStudentsByDOB(Course course, string filename);


