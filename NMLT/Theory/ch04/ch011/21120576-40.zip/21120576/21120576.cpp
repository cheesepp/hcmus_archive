#include "Date.h"
#include "Student.h"
#include "Course.h"

int main() {

	//// Test Date struct
	//Date d;
	//input(d);
	//outputDateWithFormat(d, "MMM/yyyy/dd");
	//increaseDateByK(d, 4);
	//cout << getDayOfWeek(d) << endl;


	//// Test Student struct
 //   Student student;
 //   input(student);

 //   cout << "\nXuat sinh vien:\n";
 //   output(student);

 //   cout << "\nXuat sinh vien voi tuoi:\n";
 //   outputWAge(student);

 //   string filename = "student.txt";
 //   writeStudent(student, filename);

 //   cout << "\nLoaded Student from File:\n";
 //   Student loadedStudent;
 //   readStudent(loadedStudent, filename);
 //   output(loadedStudent);

 //   extractClass(loadedStudent);

 //   compare2StdsById(student, loadedStudent);
 //   compare2StdsByGPAnId(student, loadedStudent);
 //   compare2StdsByNamenId(student, loadedStudent);
 //   compare2StdsByFNamenId(student, loadedStudent);
 //   compare2StdsByLNamenId(student, loadedStudent);
 //   compare2StdsByDobnId(student, loadedStudent);

    // Test Course struct
    Course c = loadCourseFromFile("course.txt");
    saveCourseToFile(c, "outputcourse.txt");
    Student s;
    input(s);
    addStudentToCourse(c, s);
    removeStudentFromCourse(c, s);
    saveStudentsBornInCurrentMonth(c, "curMonth.txt");
    saveStudentsBornOnCurrentDate(c, "curDate.txt");
    saveLegalDrivingStudents(c, "legalDriving.txt");
    saveStudentsInK19Class(c, "K19.txt");
    int id;
    cout << "Nhap id: ";
    cin >> id;
    findStudentById(c, id, "findId.txt");
    findStudentsByName(c, "Tri", "findName.txt");
    sortStudentsById(c, "sortId.txt");
    sortStudentsByFirstName(c, "sortFName.txt");
    sortStudentsByGPA(c, "sortGPA.txt");
    sortStudentsByDOB(c, "sortDOB.txt");



}