#include "Function.h"

// Cau 1
bool laSoNguyenTo(int n) {

	if (n < 2) return false;
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) {
			return false;
		}
	}
	return true;

}

void tinhTongSNT() {

	int n;
	cout << "Nhap so nguyen n (10 <= n <= 1000): ";
	do {
		cin >> n;
		if (n < 10 || n > 1000) {
			cout << "n phai thuoc [10, 1000]! Yeu cau nhap lai!\n";
		}
	} while (n < 10 || n > 1000);

	int sum = 0;
	for (int i = 10; i <= n; i++) {
		if (i % 10 == 1) {
			if (laSoNguyenTo(i)) {
				sum += i;
			}
		}
	}

	cout << "Tong so nguyen to: " << sum << endl;
}

// Cau 2
void tinhGTBT() {

	int x, n;
	cout << "Nhap lan luot hai so nguyen duong x va n: ";
	do {
		cin >> x >> n;
		if (n <= 0 || x <= 0) {
			cout << "Phai nhap so duong!\n";
		}
	} while (n <= 0 || x <= 0);

	double S = 0;

	for (int i = 1; i <= n; i++) {
		S += pow(-1, i - 1) * (1 * 1.0 / i) * pow(x, i);
	}

	cout << "Gia tri cua bieu thuc la: " << fixed << S << endl;
}

// Cau 3
int tongSoNguyen() {

	int n;
	cout << "Nhap so nguyen n (10 < n < 10000): ";
	do {
		cin >> n;
		if (n <= 10 || n >= 10000) {
			cout << "n phai thuoc (10, 10000)! Yeu cau nhap lai!\n";
		}
	} while (n <= 10 || n >= 10000);

	int sum = 0;

	while (n != 0) {
		sum += n % 10;
		n /= 10;
	}

	return sum;

}

// Cau 4
void docChuSo(int tongSN) {

	cout << "Tu ket qua cau 3 doc thanh: ";
	int countDigit = 0;
	int temp = tongSN;
	while (temp != 0) {
		countDigit++;
		temp /= 10;
	}
	
	while (countDigit != 0) {
		int getDigit = tongSN / pow(10, countDigit - 1);

		switch (getDigit) {
			case 0: {
				cout << "Zero ";
				break;
			}
			case 1: {
				cout << "One ";
				break;
			}
			case 2: {
				cout << "Two ";
				break;
			}
			case 3: {
				cout << "Three ";
				break;
			}
			case 4: {
				cout << "Four ";
				break;
			}
			case 5: {
				cout << "Five ";
				break;
			}
			case 6: {
				cout << "Six ";
				break;
			}
			case 7: {
				cout << "Seven ";
				break;
			}
			case 8: {
				cout << "Eight ";
				break;
			}
			case 9: {
				cout << "Nine ";
				break;
			}
		}
		countDigit--;

		int t = pow(10, countDigit);
		tongSN = tongSN % t;
	}
}