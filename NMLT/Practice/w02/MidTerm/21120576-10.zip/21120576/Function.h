#pragma once
#include <iostream>
#include <cmath>
using namespace std;

// Cau 1
bool laSoNguyenTo(int n);

void tinhTongSNT();

// Cau 2
void tinhGTBT();

// Cau 3
int tongSoNguyen();

// Cau 4
void docChuSo(int tongSN);