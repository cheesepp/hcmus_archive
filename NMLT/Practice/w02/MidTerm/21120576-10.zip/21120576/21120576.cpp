#include "Function.h"

int main() {

	// Cau 1
	cout << "=============== CAU 1 ==================\n\n";
	tinhTongSNT();
	
	// Cau 2
	cout << "\n\n=============== CAU 2 ==================\n\n";
	tinhGTBT();

	// Cau 3
	cout << "\n\n=============== CAU 3 ==================\n\n";
	int tongSN = tongSoNguyen();
	cout << "Tong so nguyen la: " << tongSN << endl;

	// Cau 4
	cout << "\n\n=============== CAU 4 ==================\n\n";
	docChuSo(tongSN);

	return 0;
}