// File xu li cac method cua stack
#include "Stack.h";

// Ham push phan tu vao stack
void Stack::push(const string& val) {
	list.insert(0, val);
}

// Ham pop phan tu vao stack
void Stack::pop() {
	list.erase(0);
}

// Ham lay phan tu nam o top cua stack
string Stack::top() const {
	return list.get(0);
}

// Ham tra ve kich thuoc cua stack
int Stack::size() const {
	return list.size();
}