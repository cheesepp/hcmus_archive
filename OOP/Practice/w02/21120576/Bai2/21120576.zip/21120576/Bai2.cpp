#include "Stack.h"

// Ham thuc thi chuong trinh
int main()
{
    Stack s;
    s.push("hehe"); // Day hehe vao stack
    cout << s.size() << endl; // Lay kich thuoc cua stack
    s.push("hihi"); // Day hihi vao stack
    cout << s.size() << endl;
    s.push("hoho");
    cout << s.size() << endl;
    s.pop(); // Lay phan tu tren dau ra khoi stack
    cout << s.top() << endl; // Tra ve phan tu tren dau cua stack
    s.pop();
    cout << s.top() << endl;
}