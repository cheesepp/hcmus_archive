﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Entities
{
    public class Entity
    {
        public int Id { get; set; }
    }
}
